// swift-tools-version:5.2

import PackageDescription

let package = Package(
    name: "TestPackageOne",
    platforms: [.macOS(.v10_15)],
    products: [
        .library(name: "Foo", targets: ["Foo"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Foo", dependencies: []),
    ]
)
