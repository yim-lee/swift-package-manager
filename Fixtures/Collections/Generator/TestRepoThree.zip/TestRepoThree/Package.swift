// swift-tools-version:5.2

import PackageDescription

let package = Package(
    name: "TestPackageThree",
    products: [
        .library(name: "Baz", targets: ["Baz"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Baz", dependencies: []),
    ]
)
