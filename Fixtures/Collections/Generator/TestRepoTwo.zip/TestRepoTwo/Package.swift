// swift-tools-version:5.2

import PackageDescription

let package = Package(
    name: "TestPackageTwo",
    products: [
        .library(name: "Bar", targets: ["Bar"]),
        .library(name: "Foo", targets: ["Foo"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Bar", dependencies: []),
        .target(name: "Foo", dependencies: []),
    ]
)
